<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ServicoController;
use App\Http\Controllers\AgendamentoController;

Route::get('', [UserController::class, 'index']);
Route::get('usuario', [UserController::class, 'getUsuario']);
Route::get('servico', [ServicoController::class, 'getServico']);
Route::get('agendamento', [AgendamentoController::class, 'getAgendamento']);
Route::get('agenda', [AgendaController::class, 'getAgenda']);

Route::get('cadastrar-usuario',[UserController::class, 'cadastrarUsuario']);
Route::get('buscar-todos-usuario',[UserController::class, 'buscarTodosUsuario']);
Route::get('buscar-usuario-especifico/{id_usuario}',[UserController::class, 'buscarUsuarioEspecifico']);
Route::get('atualizar-usuario/{id_usuario}',[UserController::class, 'atualizarUsuario']);
Route::get('deletar-usuario/{id_usuario}',[UserController::class, 'deletarUsuario']);

Route::get('cadastrar-servico',[ServicoController::class, 'cadastrarServico']);
Route::get('buscar-todos-servico',[ServicoController::class, 'buscarTodosServico']);
Route::get('buscar-servico-especifico/{id_usuario}',[ServicoController::class, 'buscarUsuarioEspServico']);
Route::get('atualizar-servico/{id_usuario}',[ServicoController::class, 'atualizarServico']);
Route::get('deletar-servico/{id_usuario}',[ServicoController::class, 'deletarServico']);

Route::get('cadastrar-agendamento',[AgendamentoController::class, 'cadastrarAgendamento']);
Route::get('buscar-todos-agendamento',[AgendamentoController::class, 'buscarTodosAgendamento']);
Route::get('buscar-agendamento-especifico/{id_usuario}',[AgendamentoController::class, 'buscarUsuarioEspAgendamento']);
Route::get('atualizar-agendamento/{id_usuario}',[AgendamentoController::class, 'atualizarAgendamento']);
Route::get('deletar-agendamento/{id_usuario}',[AgendamentoController::class, 'deletarAgendamento']);

Route::get('cadastrar-agenda',[AgendaController::class, 'cadastrarAgenda']);
Route::get('buscar-todos-agenda',[AgendaController::class, 'buscarTodosAgenda']);
Route::get('buscar-agenda-especifico/{id_usuario}',[AgendaController::class, 'buscarUsuarioEspAgenda']);
Route::get('atualizar-agenda/{id_usuario}',[AgendaController::class, 'atualizarAgenda']);
Route::get('deletar-agenda/{id_usuario}',[AgendaController::class, 'deletarAgenda']);