<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\Models\agendamento;

class AgendamentoController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function index()
    {
        return "Hello world from ServicoController - index()";
    }

    public function getAgendamento(){
        return response()->json([
            ["id_agendadamento"=> 1, "data"=> "11/05/2025", "hora"=> "8:00", "nome_cliente"=> "Bell hoocks", "nome_profissional"=> "jackie Ximenes"],

            ["id_agendadamento"=> 2, "data"=> "03/05/2025", "hora"=> "8:30", "nome_cliente"=> "Ailton Krenak" , "nome_profissional"=> "Matheus felipe"], 

            ["id_agendadamento"=> 3, "data"=> "06/05/2025", "hora"=> "9:00", "nome_cliente"=> "Machado de Assis", "nome_profissional"=> "Ian Ian"],

            ["id_agendadamento"=> 4, "data"=> "15/05/2025", "hora"=> "9:30", "nome_cliente"=> "Nise Da Silveira","nome_profissional"=> "jackie Ximenes"],

            ["id_agendadamento"=> 5, "data"=> "21/05/2025", "hora"=> "10:00", "nome_cliente"=> "Nizia Floresta", "nome_profissional"=> "Ian Ian"],

            ["id_agendadamento"=> 6, "data"=> "08/05/2025", "hora"=> "10:30", "nome_cliente"=> "Jorge Ben Jor", "nome_profissional"=> " Klynder boeno"],

            ["id_agendadamento"=> 7, "data"=> '22/05/2025', "hora"=> "11:00", "nome_cliente"=> "Erica hilton", "nome_profissional"=> "jackie Ximenes"], 

            ["id_agendadamento"=> 8, "data"=> "30/05/2025", "hora"=> "12:30", "nome_cliente"=> "Biello", "nome_profissional"=> "Matheus felipe"],

            ["id_agendadamento"=> 9, "data"=> "24/05/2025", "hora"=> "13:00", "nome_cliente"=> "Rita drag", "nome_profissional"=> " Klynder boeno"],

            ["id_agendadamento"=> 10, "data"=> "02/05/2025", "hora"=> "13:00", "nome_cliente"=> "Rafael de assis",  "nome_profissional"=> " Brian"]
        ]);
    }
}

