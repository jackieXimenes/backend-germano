<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\Models\Servico;

class ServicoController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function index()
    {
        return "Hello world from ServicoController - index()";
    }
    public function getServico(){
        return response()->json([
            ["id_servico" => 1, "nome_servico" => "Corte"],
            ["id_servico" => 2, "nome_servico" => "Barba"],
            ["id_servico" => 3, "nome_servico" => "pe"],
            ["id_servico" => 5, "nome_servico" => "corte e pe"],
            ["id_servico" => 6, "nome_servico" => "corte e barba"],
            ["id_servico" => 7, "nome_servico" => "barba e pe"],
            ["id_servico" => 4, "nome_servico" => "completo"],
            ["id_servico" => 8, "nome_servico" => "completão"],
            ["id_servico" => 9, "nome_servico" => "sombrancelha"],
            ["id_servico" => 10, "nome_servico" => "luzes"],
            ["id_servico" => 11, "nome_servico" => "corte2"],
            ["id_servico" => 12, "nome_servico" => "corte3"]
        ]);
    }
}

