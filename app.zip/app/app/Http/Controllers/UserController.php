<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Http\Request;

class UserController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function index()
    {
        return "Hello world from UserController - index()";
    }
    public function getUsuarios(){
        return response()->json([
            ["id_usuario" => 12, "nome" => "Maria Souza", "nome_Grupo" => "cliente"],
            ["id_usuario" => 19, "nome" => "Gomes FGreire", "nome_Grupo" => "cliente"],
            ["id_usuario" => 1, "nome" => "Karol", "nome_Grupo" => "admin"],
            ["id_usuario" => 2, "nome" => "Nathy", "nome_Grupo" =>"profissional"],
            ["id_usuario" => 3, "nome" => "Hanna", "nome_Grupo" => "profissional"],
            ["id_usuario" => 4, "nome" => "Germano", "nome_Grupo" => "profissional"],
            ["id_usuario" => 5, "nome" => "Cauê", "nome_Grupo" => "profissional"],
            ["id_usuario" => 6, "nome" => "Flávia", "nome_Grupo" => "cliente"],
            ["id_usuario" => 7, "nome" => "Bruno", "nome_Grupo" => "cliente"],
            ["id_usuario" => 8, "nome" => "Josué", "nome_Grupo" => "cliente"],
            ["id_usuario" => 9, "nome" => "Matheus", "nome_Grupo" => "cliente"],
            ["id_usuario" => 10, "nome" => "Ludi", "nome_Grupo" => "cliente"]
        ]);
    }
}

function cadastrarUsuario(Request $request){
    $usuarioCadastrado = User::create(
        [
            "nome" => $request->nome,
            "email" => $request->email,
            "id_grupo" => $request->id_grupo,
            "data_de_nascimento" => $request->data_de_nascimento,
            "senha" => $request->senha,
        ]
        );
}

function buscarTodosUsuario(){
    $todosOsUsuarios = User::get()->toArray
}

function buscarUsuarioEspecifico(Request $request){
    $usuario = User::find($request->id_usuario);
}
function atualizarUsuario(Request $request){
    $usuario = User::find($request->id_usuario)
    -> Update
        ([
                "nome" => $request->nome,
                "email" => $request->email,
                "id_grupo" => $request->id_grupo,
                "data_de_nascimento"=>$request -> data_de_nascimento,
                "senha" => $request->senha,
        ]);
}
function deletarUsuario(Request $request){
    $usuario = User::find($request->id_usuario)->delete();
}

