<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\Models\Servico;

class ServicoController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function index()
    {
        return "Hello world from ServicoController - index()";
    }

        function cadastrarServico(Request $request){
        $servicoCadastrado = Servico::create(
            [
                "nome" => $request->nome,
                "categoria" => $request->categoria,
                "preco" => $request->preco,
            ]
            );
    }

    function buscarTodosServico(){
        $todosOsServico = Servico::All();
    }

    function buscarUsuarioEspecificoServico(Request $request){
        $servico = Servico::find($request->id_servico);
    }
    function atualizarServico(Request $request){
        $servico = Servico::find($request->id_servico)
        -> Update
            ([
                "nome" => $request->nome,
                "categoria" => $request->categoria,
                "preco" => $request->preco,
            ]);
    }
    function deletarServico(Request $request){
        $servico = Servico::find($request->id_servico)->delete();
    }


    
}

