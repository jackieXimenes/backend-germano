<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\Models\agenda;

class AgendaController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function index()
    {
        return "Hello world from ServicoController - index()";
    }

    public function cadastrarAgenda(Request $request){
        $agendaCadastrado = Agenda::create(
            [
                "data" => $request->data,
            ]
            );
    }

    public function buscarTodosAgenda(){
        $todasAsAgenda = Agenda::All();
    }

    public function buscarUsuarioEspecificoAgenda(Request $request){
        $agenda = Agenda::find($request->id_agenda);
    }

    public function atualizarAgenda(Request $request){
        $agenda = Agenda::find($request->id_agenda)
        -> Update
            ([
            "data" => $request->data,
            ]);
    }

    public function deletarAgenda(Request $request){
        $agenda = Agenda::find($request->id_agenda)->delete();
    }
}