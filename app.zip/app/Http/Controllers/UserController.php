<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Http\Request;

class UserController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function index()
    {
        return "Hello world from UserController - index()";
    }

    function cadastrarUsuario(Request $request){
        $usuarioCadastrado = User::create(
            [
                "nome" => $request->nome,
                "email" => $request->email,
                "id_grupo" => $request->id_grupo,
                "data_de_nascimento" => $request->data_de_nascimento,
                "senha" => $request->senha,
                "status" => $request->status,
            ]
            );
    }

    function buscarTodosUsuario(){
        $todosOsUsuarios = User::All();
    }

    function buscarUsuarioEspecifico(Request $request){
        $usuario = User::find($request->id_usuario);
    }
    function atualizarUsuario(Request $request){
        $usuario = User::find($request->id_usuario)
        -> Update
            ([
                    "nome" => $request->nome,
                    "email" => $request->email,
                    "id_grupo" => $request->id_grupo,
                    "data_de_nascimento"=>$request -> data_de_nascimento,
                    "senha" => $request->senha,
                    "status" => $request->status,
            ]);
    }
    function deletarUsuario(Request $request){
        $usuario = User::find($request->id_usuario)->delete();
    }
}
