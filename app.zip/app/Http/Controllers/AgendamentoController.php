<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\Models\agendamento;

class AgendamentoController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function index()
    {
        return "Hello world from ServicoController - index()";
    }

    public function cadastrarAgendamento(Request $request){
        $agendamentoCadastrado = Agendamento::create(
            [
                "data" => $request->data,
                "hora" => $request->hora,
            ]
            );
    }

    public function buscarTodosAgendamento(){
        $todosOsAgendamento = Agendamento::All();
    }

    public function buscarUsuarioEspecificoAgendamento(Request $request){
        $agendamento = Agendamento::find($request->id_agendamento);
    }
    public function atualizarAgendamento(Request $request){
        $agendamento = Agendamento::find($request->id_agendamento)
        -> Update
            ([
                    "data" => $request->data,
                    "hora" => $request->hora,
            ]);
    }
    public function deletarAgendamento(Request $request){
        $agendamento = Agendamento::find($request->id_agendamento)->delete();
    }
}